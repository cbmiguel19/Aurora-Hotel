# Aurora Hotel — projeto da Agenda 13

Projeto acadêmico baseado no código-fonte MauiAppHotel indicado na Agenda 13.

## O que foi implementado

- Interface de contratação de hospedagem personalizada com identidade visual do Aurora Hotel.
- Controles `Stepper` para adultos e crianças.
- `Picker` para selecionar o tipo de acomodação.
- `DatePicker` para check-in e check-out, com validação do período.
- `BindingContext` na tela de confirmação para apresentar os dados da reserva.
- Tela **Sobre**, acessível pela opção no topo da tela, com desenvolvedor e ano de desenvolvimento.
- Tela de confirmação e cálculo demonstrativo do valor da estadia.

## Observação sobre os valores

Os preços por suíte e os adicionais de hóspedes são valores fictícios/demonstrativos para a atividade, não tarifas reais de um hotel.

## Como executar

1. Extraia o arquivo ZIP.
2. Abra `MauiAppHotel.sln` no Visual Studio com a carga de trabalho **.NET MAUI** instalada.
3. Aguarde a restauração dos pacotes NuGet.
4. Esta versão está configurada somente para Windows. Selecione `Windows Machine` como destino. Os destinos Android, iOS e Mac Catalyst foram retirados desta cópia para evitar a restauração de SDKs que não são necessários para executar a atividade no computador Windows.
5. Execute com **F5**.
6. Na tela inicial, clique em **Sobre** na barra superior para abrir a tela solicitada na atividade.

O projeto foi preparado com base no .NET 8 MAUI do repositório original e esta cópia está configurada para executar somente no Windows. Não foi possível executar uma compilação neste ambiente porque o SDK `dotnet` e o ambiente de execução MAUI não estão instalados aqui; portanto, faça a primeira execução no Visual Studio e observe qualquer mensagem de compilação.

## Capturas de tela para a entrega

Depois de executar no Visual Studio, abra a tela **Sobre** e faça uma captura de tela em que apareçam o nome do aplicativo, o desenvolvedor e o ano. Salve a imagem em uma pasta chamada `Capturas-Sobre`. Compacte essa pasta em ZIP para anexar junto ao link do seu repositório GitHub.
