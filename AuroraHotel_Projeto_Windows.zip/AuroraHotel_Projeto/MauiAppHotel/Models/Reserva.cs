using System.Globalization;

namespace MauiAppHotel.Models;

public class Reserva
{
    private static readonly CultureInfo CulturaBrasileira = new("pt-BR");

    public int Adultos { get; set; }
    public int Criancas { get; set; }
    public string Acomodacao { get; set; } = string.Empty;
    public DateTime CheckIn { get; set; }
    public DateTime CheckOut { get; set; }
    public decimal ValorDiaria { get; set; }
    public decimal ValorTotal { get; set; }

    public int Diarias => Math.Max(1, (CheckOut.Date - CheckIn.Date).Days);
    public string Hospedes => $"{Adultos} adulto(s) • {Criancas} criança(s)";
    public string CheckInFormatado => CheckIn.ToString("dd/MM/yyyy", CulturaBrasileira);
    public string CheckOutFormatado => CheckOut.ToString("dd/MM/yyyy", CulturaBrasileira);
    public string DiariasFormatadas => $"{Diarias} diária(s)";
    public string ValorDiariaFormatado => ValorDiaria.ToString("C2", CulturaBrasileira);
    public string ValorTotalFormatado => ValorTotal.ToString("C2", CulturaBrasileira);
}
