﻿namespace MauiAppHotel
{
    public partial class App : Application
    {
        public App()
        {
            InitializeComponent();

            MainPage = new NavigationPage(new Views.ContratacaoHospedagem())
            {
                BarBackgroundColor = Color.FromArgb("#14243A"),
                BarTextColor = Colors.White
            };
        }

        protected override Window CreateWindow(IActivationState? activationState)
        {
            var window = base.CreateWindow(activationState);

            // Tamanho inicial confortável para executar a aplicação no Windows.
            window.Width = 430;
            window.Height = 850;

            return window;
        }
    }
}
