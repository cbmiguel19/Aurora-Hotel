using MauiAppHotel.Models;

namespace MauiAppHotel.Views;

public partial class ContratacaoHospedagem : ContentPage
{
    private readonly Dictionary<string, decimal> _tarifas = new()
    {
        ["Suíte Clássica"] = 280m,
        ["Suíte Jardim"] = 360m,
        ["Suíte Família"] = 480m,
        ["Suíte Premium"] = 620m
    };

    private decimal _valorDiariaCalculado;
    private decimal _valorTotalCalculado;

    public ContratacaoHospedagem()
    {
        InitializeComponent();

        pck_quarto.ItemsSource = _tarifas.Keys.ToList();
        pck_quarto.SelectedIndex = 0;

        dtpck_checkin.MinimumDate = DateTime.Today;
        dtpck_checkin.Date = DateTime.Today;
        dtpck_checkout.MinimumDate = DateTime.Today.AddDays(1);
        dtpck_checkout.Date = DateTime.Today.AddDays(1);
        dtpck_checkin.DateSelected += OnCheckinDateSelected;
    }

    private void OnCheckinDateSelected(object? sender, DateChangedEventArgs e)
    {
        dtpck_checkout.MinimumDate = e.NewDate.AddDays(1);

        if (dtpck_checkout.Date <= e.NewDate)
            dtpck_checkout.Date = e.NewDate.AddDays(1);

        card_total.IsVisible = false;
    }

    private async void OnCalcularClicked(object sender, EventArgs e)
    {
        if (!await ValidarFormularioAsync())
            return;

        CalcularValores();
        card_total.IsVisible = true;
        lbl_valor_diaria.Text = _valorDiariaCalculado.ToString("C2", new System.Globalization.CultureInfo("pt-BR"));
        lbl_quantidade_diarias.Text = $"{(dtpck_checkout.Date.Date - dtpck_checkin.Date.Date).Days} diária(s)";
        lbl_valor_total.Text = _valorTotalCalculado.ToString("C2", new System.Globalization.CultureInfo("pt-BR"));
    }

    private async Task<bool> ValidarFormularioAsync()
    {
        if (pck_quarto.SelectedIndex < 0)
        {
            await DisplayAlert("Acomodação", "Selecione uma suíte para continuar.", "OK");
            return false;
        }

        if (dtpck_checkout.Date.Date <= dtpck_checkin.Date.Date)
        {
            await DisplayAlert("Período inválido", "O check-out deve ser posterior ao check-in.", "OK");
            return false;
        }

        return true;
    }

    private void CalcularValores()
    {
        string acomodacao = pck_quarto.SelectedItem?.ToString() ?? "Suíte Clássica";
        int adultos = (int)stp_adultos.Value;
        int criancas = (int)stp_criancas.Value;
        int diarias = (dtpck_checkout.Date.Date - dtpck_checkin.Date.Date).Days;

        // Tarifas ilustrativas: a primeira pessoa adulta está incluída na diária.
        decimal adicionalAdultos = Math.Max(0, adultos - 1) * 60m;
        decimal adicionalCriancas = criancas * 30m;
        _valorDiariaCalculado = _tarifas[acomodacao] + adicionalAdultos + adicionalCriancas;
        _valorTotalCalculado = _valorDiariaCalculado * diarias;
    }

    private async void OnConfirmarClicked(object sender, EventArgs e)
    {
        if (!await ValidarFormularioAsync())
            return;

        CalcularValores();

        var reserva = new Reserva
        {
            Adultos = (int)stp_adultos.Value,
            Criancas = (int)stp_criancas.Value,
            Acomodacao = pck_quarto.SelectedItem?.ToString() ?? "Suíte Clássica",
            CheckIn = dtpck_checkin.Date,
            CheckOut = dtpck_checkout.Date,
            ValorDiaria = _valorDiariaCalculado,
            ValorTotal = _valorTotalCalculado
        };

        await Navigation.PushAsync(new HospedagemContratada(reserva));
    }

    private async void OnSobreClicked(object sender, EventArgs e)
    {
        await Navigation.PushAsync(new Sobre());
    }
}
